package example.pkg;

import java.util.List;

public class Animal {
private double weight;
private float height;
private String names;
private Color color;

private List<String> animalnames;

public Animal()
{
	
}

public Animal(double weight, float height, String names, Color color) {
	super();
	this.weight = weight;
	this.height = height;
	this.names = names;
	this.color = color;
}
public double getWeight() {
	return weight;
}
public void setWeight(double weight) {
	this.weight = weight;
}
public float getHeight() {
	return height;
}
public void setHeight(float height) {
	this.height = height;
}
public String getNames() {
	return names;
}
public void setNames(String names) {
	this.names = names;
}
public Color getColor() {
	return color;
}
public void setColor(Color color) {
	this.color = color;
}

public List<String> getAnimalnames() {
	return animalnames;
}

public void setAnimalnames(List<String> animalnames) {
	this.animalnames = animalnames;
}


}
