package example.pkg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ApplicationStart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ac = new ClassPathXmlApplicationContext("Beans.xml");
		/*
		 * Point p=(Point)ac.getBean("Point10"); System.out.println(p.getX());
		 * System.out.println(p.getY());
		 */
		
		/*
		 * Calculator c = (Calculator) ac.getBean("calculate");
		 * System.out.println(c.add()); System.out.println(c.subtract());
		 * System.out.println(c.multiply()); System.out.println(c.divide());
		 */

		Animal a = (Animal) ac.getBean("ani");
		System.out.println(a.getAnimalnames());
		
		//Color c= (Color) ac.getBean("blackandwhite");
		/*
		 * System.out.println(a.getWeight()); System.out.println(a.getHeight());
		 * System.out.println(a.getNames());
		 */
		/*
		 * System.out.println(a.getColor().getColorName());
		 * System.out.println(a.getColor().getColorId());
		 */
		//System.out.println(c.getColorId());
		
	
	}

}
